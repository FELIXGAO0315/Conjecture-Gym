# PolyForge — Proof Trajectory Samples

6 machine-generated graph-theory conjectures, each with a Lean 4 proof that
compiles against Mathlib (no `sorry`, no extra axioms), plus the full
proof-trajectory record used to generate/score it.

## Contents
```
proofs/C*/   C*.lean  Lean 4 proof
             C*.md    human-readable statement + structured proof
             C*.json  full proof-trajectory record (steps, IRIS, hardness, costs)
lean/        GraphLemmas.lean   dependency: self-proved inventory lemmas the proofs import
             lakefile.lean / lean-toolchain / lake-manifest.json   build config
```

## Samples

| id | formula | hardness | IRIS | Lean |
|----|---------|----------|------|------|
| C66 | `if ((is_regular(3))), then (3*alpha >= -2*chi + 11)` | 43.75 | 1.333 | compiled |
| C244 | `if ((is_bipartite) and (is_connected) and (min_deg <= 4)), then (m >= 2*min_deg + 2*tau - 4)` | 13.5 | 1.203 | compiled |
| C76 | `if ((not_bipartite) and (tau <= 5)), then (2*alpha >= -m + 3*min_deg - 1)` | 15.8 | 1.184 | compiled |
| C289 | `if ((is_connected) and (n >= 3)), then (chi <= 3*m - 3*min_deg)` | 17.9 | 1.001 | compiled |
| C156 | `if ((max_deg <= 4)), then (2*min_deg <= 2*chi + 3*alpha - 4)` | 26.3 | 1.001 | compiled |
| C70 | `if ((alpha <= 2*tau) and (m >= 5)), then (2*m >= -3*chi - 3*alpha + 25)` | 23.5625 | 0.534 | compiled |

Invariants: n=|V|, m=#edges, max_deg/min_deg, chi=chromatic number,
omega=clique number, alpha=independence number, tau=vertex-cover number,
diam, radius, girth.

## Reproducing the Lean proofs

Toolchain: **Lean 4 v4.34.0 + Mathlib v4.34.0** (pinned in `lean/lean-toolchain`
and `lean/lake-manifest.json`).

```bash
cd lean
cp ../proofs/C*/C*.lean .      # drop the proof files next to GraphLemmas.lean
lake exe cache get             # fetch prebuilt Mathlib (no full rebuild)
lake build                     # builds GraphLemmas + the C* proofs
```

Each `C*.lean` begins with `import Mathlib` and `import GraphLemmas`, so it needs
only this project plus the pinned Mathlib — nothing else.

